# StudySync — Improved

A Java Swing study planner. Tracks subjects, computes a priority-weighted
daily plan, records actual hours studied, and shows a 7-day progress report.

## Build & Run

```bash
./compile.sh   # requires JDK 16+
./run.sh
```

Manually:
```bash
javac -d out $(find src -name "*.java")
java  -cp out com.studysync.Main
```

## What changed in this revision

### Core-logic bugs fixed

| # | Bug | Fix |
|---|-----|-----|
| 1 | `Main` set Look-and-Feel off the Event Dispatch Thread | All Swing setup now runs inside `SwingUtilities.invokeLater` |
| 2 | `StudyPlanner` forced every subject to ≥1 h via `Math.max(1, …)`, drowning out priority when many subjects existed | Removed the floor; allocation is strictly proportional to priority |
| 3 | Redistribution loop was capped at `priorities.size() * 2`, leaving leftover hours unallocated | Loop now runs until no subject can take another hour |
| 4 | Possible division by zero when `totalPriority == 0` | Guarded with a uniform fallback ratio |
| 5 | Planner assumed **1 h ≈ 10 %** but Daily Check-in awarded `20 × (actual/planned) %` — re-studying the planned amount only ever moved completion 20 %, regardless of subject length | Both modules now share `StudyPlanner.PERCENT_PER_HOUR = 10`. Studying 1 h moves completion by 10 % |
| 6 | Daily Check-in was **not idempotent** — re-submitting the same day double-counted completion | Submit reads the prior actual hours for today and credits only the *delta*; re-opening the dialog pre-fills the existing entry |
| 7 | `UserRepository` legacy Base64 entries (e.g. the bundled `Anmol,MTIzNA==`) silently failed to log in | Legacy records are now validated against `Base64(password)` and auto-migrated to the salted-hash format on first successful login |
| 8 | `FileUtils.nextId` was a static counter shared across users | Removed; `DataRepository.nextNewId()` derives the next ID from the user's own subject list |
| 9 | `Subject.toFileString` wrote raw names (no URL-encoding) — corrupting the file for names with spaces | Removed; only `FileUtils.toFileLine` (URL-encoded) is used |
| 10 | `DailyCheckinUI.buildUI` added three different components to `BorderLayout.NORTH` | Single combined NORTH panel with header + instruction |
| 11 | `StudyPlanUI` accepted negative or 0 hours | Validated to 1..24 |
| 12 | `AddSubjectUI` accepted any days-left and duplicate names | Range 1..365, case-insensitive duplicate check |
| 13 | `Subject` setters didn't clamp inputs | Setters clamp to legal ranges (difficulty 1..5, completion 0..100, daysLeft ≥ 0) |
| 14 | Subjects-table column 3 had two cell renderers wired up | Single renderer; ID & Days centred, ID width capped |

### Security (kept from previous revision, hardened)

- SHA-256 + 16-byte random salt for password storage (no Base64 "encryption")
- Min-8-char passwords, 500 ms delay on failed login
- Strict username regex blocks path-traversal usernames
- File writes go through `Files.move(..., ATOMIC_MOVE)` (was best-effort `delete + rename`)
- All file IO is explicitly UTF-8 (was platform default)

### UI polish

- **Login**: default button now switches correctly between the login and signup cards; signup confirm field also submits on Enter.
- **Dashboard**: KPI cards now actually render the coloured accent strip referenced in the original code; subjects table has centred ID / Days-Left columns and a help-text line.
- **Daily Check-in**: gradient header, the dialog explains the 1 h ≈ 10 % rule and idempotent re-submit, prior actuals pre-fill on re-open.
- **Study Plan**: priority labels go through `PriorityEngine.label` for consistency between Dashboard and Plan dialog.
