#!/usr/bin/env bash
# Compile StudySync. Requires JDK 16+ (uses switch expressions).
set -e
rm -rf out
mkdir -p out
find src -name "*.java" -print0 | xargs -0 javac -d out -sourcepath src
echo "Compiled OK. Run with:  java -cp out com.studysync.Main"
