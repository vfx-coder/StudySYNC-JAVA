package com.studysync.auth;

import com.studysync.repository.UserRepository;

public class AuthService {

    private final UserRepository userRepo;
    private String currentUser;

    // Milliseconds to sleep on each failed login attempt (anti-brute-force)
    private static final long FAILED_LOGIN_DELAY_MS = 500;

    public AuthService() {
        this.userRepo    = new UserRepository();
        this.currentUser = null;
    }

    public boolean signup(String username, String password) {
        if (!UserRepository.isValidUsername(username)) {
            showError("Username must be 1-32 chars (letters, digits, _ or -).");
            return false;
        }

        if (password == null || password.length() < 8) {
            showError("Password must be at least 8 characters.");
            return false;
        }

        if (userRepo.userExists(username)) {
            showError("Username already exists.");
            return false;
        }

        if (userRepo.getUserCount() >= 10) {
            showError("Maximum 10 users reached.");
            return false;
        }

        userRepo.saveUser(username, password);
        return true;
    }

    public boolean login(String username, String password) {
        if (!UserRepository.isValidUsername(username)) {
            applyFailedDelay();
            return false;
        }

        if (userRepo.validateUser(username, password)) {
            currentUser = username;
            return true;
        }

        applyFailedDelay();
        return false;
    }

    public void logout() {
        currentUser = null;
    }

    public String getCurrentUser() { return currentUser; }
    public boolean isLoggedIn()    { return currentUser != null; }

    private void applyFailedDelay() {
        try { Thread.sleep(FAILED_LOGIN_DELAY_MS); } catch (InterruptedException ignored) {}
    }

    private void showError(String msg) {

        System.err.println("[Auth] " + msg);
    }
}
