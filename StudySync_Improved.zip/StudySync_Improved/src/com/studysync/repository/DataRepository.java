package com.studysync.repository;

import java.io.File;
import java.util.*;
import com.studysync.model.Subject;
import com.studysync.utils.FileUtils;

public class DataRepository {

    private final String       currentUser;
    private final String       filename;
    private List<Subject>      subjects;

    public DataRepository(String username) {
        this.currentUser = username;
        this.filename    = "data" + File.separator + username + "_data.txt";
        this.subjects    = FileUtils.loadSubjects(filename);
    }

    public void saveData() { FileUtils.saveSubjects(subjects, filename); }

    public List<Subject> getSubjects() { return new ArrayList<>(subjects); }

    public int nextNewId() { return FileUtils.peekNextId(subjects); }

    public Subject addSubject(Subject s) {
        subjects.add(s);
        saveData();
        return s;
    }

    public boolean deleteSubject(int id) {
        Subject toRemove = findById(id);
        if (toRemove == null) return false;
        subjects.remove(toRemove);
        saveData();
        return true;
    }

    public void updateSubject(Subject updated) {
        for (int i = 0; i < subjects.size(); i++) {
            if (subjects.get(i).getId() == updated.getId()) {
                subjects.set(i, updated);
                saveData();
                return;
            }
        }
    }

    public Subject findById(int id) {
        for (Subject s : subjects) if (s.getId() == id) return s;
        return null;
    }

    public String getCurrentUser() { return currentUser; }
}
