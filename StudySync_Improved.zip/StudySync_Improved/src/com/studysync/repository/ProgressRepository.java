package com.studysync.repository;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

public class ProgressRepository {
    private final String currentUser;
    private final String progressFile;
    private final Map<String, Map<Integer, DailyProgress>> progressData;

    public ProgressRepository(String username) {
        this.currentUser  = username;
        this.progressFile = "data" + File.separator + username + "_progress.txt";
        this.progressData = new LinkedHashMap<>();
        loadProgress();
    }

    private void loadProgress() {
        File file = new File(progressFile);
        if (!file.exists()) return;

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                String[] parts = line.split(",");
                if (parts.length != 4) continue;
                try {
                    String date      = parts[0];
                    int    subjectId = Integer.parseInt(parts[1]);
                    double allocated = Double.parseDouble(parts[2]);
                    double actual    = Double.parseDouble(parts[3]);
                    progressData.computeIfAbsent(date, k -> new HashMap<>())
                                .put(subjectId, new DailyProgress(allocated, actual));
                } catch (NumberFormatException ignored) { /* skip */ }
            }
        } catch (IOException e) {
            System.err.println("[ProgressRepo] Load error: " + e.getMessage());
        }
    }

    public void saveProgress() {
        File dest = new File(progressFile);
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        File tmp = new File(progressFile + ".tmp");

        try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
            for (Map.Entry<String, Map<Integer, DailyProgress>> dateEntry : progressData.entrySet()) {
                String date = dateEntry.getKey();
                for (Map.Entry<Integer, DailyProgress> se : dateEntry.getValue().entrySet()) {
                    DailyProgress dp = se.getValue();
                    writer.println(date + "," + se.getKey() + "," + dp.allocatedHours + "," + dp.actualHours);
                }
            }
        } catch (IOException e) {
            System.err.println("[ProgressRepo] Save error: " + e.getMessage());
            return;
        }
        try {
            Files.move(tmp.toPath(), dest.toPath(),
                    StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ame) {
            try { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException e) { System.err.println("[ProgressRepo] move failed: " + e.getMessage()); }
        } catch (IOException e) {
            System.err.println("[ProgressRepo] move failed: " + e.getMessage());
        }
    }

    public void recordProgress(String date, int subjectId, double allocated, double actual) {
        progressData.computeIfAbsent(date, k -> new HashMap<>())
                    .put(subjectId, new DailyProgress(allocated, actual));
        saveProgress();
    }

    public double getActualHours(String date, int subjectId) {
        Map<Integer, DailyProgress> day = progressData.get(date);
        if (day == null) return 0;
        DailyProgress dp = day.get(subjectId);
        return dp == null ? 0 : dp.actualHours;
    }

    public double getDailyEfficiency(String date) {
        Map<Integer, DailyProgress> day = progressData.get(date);
        if (day == null || day.isEmpty()) return 0;
        double totalAllocated = 0, totalActual = 0;
        for (DailyProgress dp : day.values()) {
            totalAllocated += dp.allocatedHours;
            totalActual    += dp.actualHours;
        }
        return (totalAllocated == 0) ? 0 : (totalActual / totalAllocated) * 100;
    }

    public double getWeeklyEfficiency() {
        double total = 0; int count = 0;
        LocalDate today = LocalDate.now();
        for (int i = 0; i < 7; i++) {
            String ds = today.minusDays(i).toString();
            if (progressData.containsKey(ds)) {
                total += getDailyEfficiency(ds);
                count++;
            }
        }
        return (count == 0) ? 0 : total / count;
    }

    public boolean hasDataForDate(String date) { return progressData.containsKey(date); }

    public Map<String, Map<Integer, DailyProgress>> getProgressData() {
        return Collections.unmodifiableMap(progressData);
    }

    public String statusLabel(double eff) {
        if (eff >= 80) return "Excellent";
        if (eff >= 60) return "Good";
        if (eff >= 40) return "Average";
        if (eff >  0)  return "Needs Improvement";
        return "No Data";
    }

    public static class DailyProgress {
        public final double allocatedHours;
        public final double actualHours;
        DailyProgress(double a, double b) { allocatedHours = a; actualHours = b; }
    }
}
