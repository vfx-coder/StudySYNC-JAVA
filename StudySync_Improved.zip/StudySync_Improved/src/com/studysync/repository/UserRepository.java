package com.studysync.repository;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.*;

public class UserRepository {

    private static final String DATA_DIR  = "data";
    private static final String FILENAME  = DATA_DIR + File.separator + "users.txt";
    private static final int    SALT_BYTES = 16;

    public UserRepository() { new File(DATA_DIR).mkdirs(); }

    public static boolean isValidUsername(String username) {
        if (username == null || username.isBlank()) return false;
        if (username.length() > 32) return false;
        return username.matches("[A-Za-z0-9_\\-]+");
    }

    public boolean userExists(String username)   { return loadUsers().containsKey(username); }
    public int     getUserCount()                { return loadUsers().size(); }

    public void saveUser(String username, String password) {
        Map<String, String> users = loadUsers();
        users.put(username, hashPassword(password, generateSalt()));
        saveUsers(users);
    }

    public boolean validateUser(String username, String password) {
        Map<String, String> users = loadUsers();
        if (!users.containsKey(username)) return false;
        String stored = users.get(username);

        if (stored.contains(":")) {
            String[] parts = stored.split(":");
            if (parts.length != 2) return false;
            try {
                String computed = hashPassword(password, parts[0]);
                return MessageDigest.isEqual(
                        hexToBytes(parts[1]),
                        hexToBytes(computed.split(":")[1]));
            } catch (Exception e) {
                return false;
            }
        }

        try {
            String legacy = Base64.getEncoder().encodeToString(
                    password.getBytes(StandardCharsets.UTF_8));
            byte[] a = legacy.getBytes(StandardCharsets.UTF_8);
            byte[] b = stored.getBytes(StandardCharsets.UTF_8);
            if (a.length == b.length && MessageDigest.isEqual(a, b)) {
                users.put(username, hashPassword(password, generateSalt()));
                saveUsers(users);
                return true;
            }
        } catch (Exception ignored) {}
        return false;
    }

    private synchronized Map<String, String> loadUsers() {
        Map<String, String> users = new LinkedHashMap<>();
        File file = new File(FILENAME);
        if (!file.exists()) return users;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                int comma = line.indexOf(',');
                if (comma < 1) continue;
                users.put(line.substring(0, comma), line.substring(comma + 1));
            }
        } catch (IOException e) {
            System.err.println("[UserRepository] Error loading users: " + e.getMessage());
        }
        return users;
    }

    private synchronized void saveUsers(Map<String, String> users) {
        File dest = new File(FILENAME);
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        File tmp = new File(FILENAME + ".tmp");
        try (PrintWriter w = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
            for (Map.Entry<String, String> e : users.entrySet()) {
                w.println(e.getKey() + "," + e.getValue());
            }
        } catch (IOException e) {
            System.err.println("[UserRepository] Error writing users: " + e.getMessage());
            return;
        }
        try {
            Files.move(tmp.toPath(), dest.toPath(),
                    StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ame) {
            try { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException e) { System.err.println("[UserRepository] move failed: " + e.getMessage()); }
        } catch (IOException e) {
            System.err.println("[UserRepository] move failed: " + e.getMessage());
        }
    }

    private String generateSalt() {
        byte[] bytes = new byte[SALT_BYTES];
        new SecureRandom().nextBytes(bytes);
        return bytesToHex(bytes);
    }

    private String hashPassword(String password, String hexSalt) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(hexToBytes(hexSalt));
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));
            return hexSalt + ":" + bytesToHex(hash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 not available", e);
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format("%02x", b));
        return sb.toString();
    }

    private static byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2)
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                                 + Character.digit(hex.charAt(i + 1), 16));
        return data;
    }
}
