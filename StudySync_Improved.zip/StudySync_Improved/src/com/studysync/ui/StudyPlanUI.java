package com.studysync.ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import com.studysync.model.Subject;
import com.studysync.repository.DataRepository;
import com.studysync.planner.StudyPlanner;
import com.studysync.core.PriorityEngine;

import static com.studysync.ui.DashboardUI.*;

public class StudyPlanUI extends JDialog {

    private final DataRepository dataRepo;
    private final DashboardUI    parent;
    private DefaultTableModel tableModel;
    private JLabel totalLabel;
    private JTextField hoursField;
    private Map<Integer, Integer> generatedPlan = new HashMap<>();
    private int generatedHours = 0;

    public StudyPlanUI(DataRepository dataRepo, DashboardUI parent) {
        super(parent, "Generate Study Plan", true);
        this.dataRepo = dataRepo;
        this.parent   = parent;
        buildUI();
    }

    private void buildUI() {
        setSize(820, 560);
        setLocationRelativeTo(parent);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(C_BG);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(C_INDIGO);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel title = new JLabel("Smart Study Plan Generator");
        title.setFont(new Font("Segoe UI", Font.BOLD, 18));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);

        JPanel hrPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        hrPanel.setBackground(C_INDIGO);
        JLabel hrLbl = new JLabel("Available study hours:");
        hrLbl.setForeground(Color.WHITE); hrLbl.setFont(F_BODY);
        hoursField = new JTextField(4);
        hoursField.setFont(F_BODY);
        int preloaded = parent.getCalculatedStudyHours();
        hoursField.setText(preloaded > 0 ? String.valueOf(preloaded) : "8");
        hoursField.setBorder(new EmptyBorder(4, 8, 4, 8));
        JButton gen = new JButton("Generate");
        gen.setFont(F_BOLD); gen.setForeground(C_INDIGO);
        gen.setBackground(Color.WHITE);
        gen.setFocusPainted(false);
        gen.setBorderPainted(false);
        gen.setCursor(new Cursor(Cursor.HAND_CURSOR));
        gen.addActionListener(e -> {
            try {
                int h = Integer.parseInt(hoursField.getText().trim());
                if (h <= 0 || h > 24) {
                    JOptionPane.showMessageDialog(this, "Hours must be between 1 and 24.",
                            "Invalid input", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                generatedHours = h;
                generatePlan(generatedHours);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this,"Enter a valid number.");
            }
        });
        hrPanel.add(hrLbl); hrPanel.add(hoursField); hrPanel.add(gen);
        header.add(hrPanel, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        String[] cols = {"Subject","Hours","Current","After Study","Days Left","Priority"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = new JTable(tableModel);
        table.setRowHeight(34);
        table.setFont(F_BODY);
        table.setGridColor(C_BORDER);
        table.setShowVerticalLines(false);
        JTableHeader h = table.getTableHeader();
        h.setFont(F_BOLD); h.setBackground(C_SLATE); h.setForeground(Color.WHITE);
        h.setPreferredSize(new Dimension(0, 34));

        table.getColumnModel().getColumn(5).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                String s = v == null ? "" : v.toString();
                if (!sel) {
                    if (s.contains("High"))        { c.setForeground(C_ROSE);    c.setBackground(new Color(255,240,240)); }
                    else if (s.contains("Medium")) { c.setForeground(C_AMBER);   c.setBackground(new Color(255,252,235)); }
                    else                            { c.setForeground(C_EMERALD); c.setBackground(new Color(240,255,248)); }
                }
                return c;
            }
        });

        root.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout(12, 0));
        footer.setBackground(C_BG);
        footer.setBorder(new EmptyBorder(10, 20, 14, 20));

        totalLabel = new JLabel("Enter hours above and click Generate.");
        totalLabel.setFont(F_BODY); totalLabel.setForeground(C_MUTED);
        footer.add(totalLabel, BorderLayout.WEST);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btns.setOpaque(false);

        JButton apply = gradBtn("Show in Dashboard", C_INDIGO);
        apply.addActionListener(e -> {
            if (generatedPlan.isEmpty()) { JOptionPane.showMessageDialog(this,"Generate a plan first."); return; }
            parent.updatePlanTable(generatedPlan, dataRepo.getSubjects(), generatedHours);
            JOptionPane.showMessageDialog(this,"Study plan updated in Dashboard!","Done",JOptionPane.INFORMATION_MESSAGE);
            dispose();
        });
        JButton close = gradBtn("Close", C_MUTED);
        close.addActionListener(e -> dispose());
        btns.add(apply); btns.add(close);
        footer.add(btns, BorderLayout.EAST);
        root.add(footer, BorderLayout.SOUTH);

        setContentPane(root);
        setVisible(true);
    }

    private void generatePlan(int hours) {
        List<Subject> subs = dataRepo.getSubjects();
        if (subs.isEmpty()) { JOptionPane.showMessageDialog(this,"No subjects found."); return; }
        generatedPlan = StudyPlanner.generatePlan(subs, hours);
        if (generatedPlan.isEmpty()) { JOptionPane.showMessageDialog(this,"No subjects need study time."); return; }

        tableModel.setRowCount(0);
        int total = 0;
        for (Subject s : subs) {
            int h = generatedPlan.getOrDefault(s.getId(), 0);
            if (h <= 0) continue;
            total += h;
            int after = Math.min(100, s.getCompletion() + h * StudyPlanner.PERCENT_PER_HOUR);
            double pri = PriorityEngine.calculatePriority(s);
            String label = PriorityEngine.label(pri) + " Priority";
            tableModel.addRow(new Object[]{s.getName(), h + "h",
                    s.getCompletion() + "%", after + "%", s.getDaysLeft(), label});
        }
        totalLabel.setText("Total: " + total + " / " + hours + " hours allocated");
        if (total < hours) {
            JOptionPane.showMessageDialog(this, (hours - total) + " hours unused - all active subjects covered!",
                    "Note", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private JButton gradBtn(String text, Color bg) {
        JButton b = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.dispose(); super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE); b.setFont(F_BOLD);
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(170, 34)); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }
}
