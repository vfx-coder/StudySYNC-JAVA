package com.studysync.ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.util.*;
import java.util.List;
import com.studysync.model.Subject;
import com.studysync.repository.DataRepository;
import com.studysync.repository.ProgressRepository;
import com.studysync.utils.DateUtils;
import com.studysync.planner.StudyPlanner;

import static com.studysync.ui.DashboardUI.*;

public class DailyCheckinUI extends JDialog {

    private final DataRepository     dataRepo;
    private final ProgressRepository progressRepo;
    private final DashboardUI        parent;

    private DefaultTableModel tableModel;
    private Map<Integer, Integer> currentPlan = new HashMap<>();
    private JLabel remainingLabel;
    private JLabel totalLabel;
    private int totalPlanned = 0;

    public DailyCheckinUI(DataRepository dataRepo, ProgressRepository progressRepo, DashboardUI parent) {
        super(parent, "Daily Check-in", true);
        this.dataRepo     = dataRepo;
        this.progressRepo = progressRepo;
        this.parent       = parent;
        buildUI();
        loadPlan();
    }

    private void buildUI() {
        setSize(920, 600);
        setLocationRelativeTo(parent);

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(C_BG);

        JPanel header = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0, 0, C_EMERALD, getWidth(), 0, new Color(5, 150, 105)));
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        header.setOpaque(false);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel title = new JLabel("Daily Check-in - " + DateUtils.formatDate(DateUtils.getCurrentDate()));
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);

        remainingLabel = new JLabel("Remaining: --");
        remainingLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        remainingLabel.setForeground(Color.WHITE);
        header.add(remainingLabel, BorderLayout.EAST);

        JLabel instr = new JLabel(
            "<html><center>Enter the <b>actual hours studied</b> for each subject today.<br>" +
            "1 hour = 10% completion. Re-submitting overwrites today's record (no double-count).</center></html>",
            SwingConstants.CENTER);
        instr.setFont(F_BODY); instr.setForeground(C_MUTED);
        instr.setBorder(new EmptyBorder(10, 20, 4, 20));

        JPanel north = new JPanel(new BorderLayout());
        north.setBackground(C_BG);
        north.add(header, BorderLayout.NORTH);
        north.add(instr,  BorderLayout.SOUTH);
        root.add(north, BorderLayout.NORTH);

        String[] cols = {"Subject","Planned (h)","Studied (h)","Remaining (h)","Status"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return c == 2; }
        };
        JTable table = new JTable(tableModel);
        table.setRowHeight(36); table.setFont(F_BODY);
        table.setGridColor(C_BORDER); table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(224,231,255));
        JTableHeader h = table.getTableHeader();
        h.setFont(F_BOLD); h.setBackground(C_SLATE); h.setForeground(Color.WHITE);
        h.setPreferredSize(new Dimension(0, 34));

        table.getColumnModel().getColumn(2).setCellEditor(new SpinnerEditor());

        tableModel.addTableModelListener(e -> {
            if (e.getColumn() == 2) SwingUtilities.invokeLater(this::refreshRemaining);
        });

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                if (!sel) {
                    String status = tableModel.getValueAt(row, 4).toString();
                    if      (status.contains("Done"))    c.setBackground(new Color(240,255,248));
                    else if (status.contains("Partial")) c.setBackground(new Color(255,252,235));
                    else                                 c.setBackground(row%2==0 ? Color.WHITE : new Color(248,250,252));
                    c.setForeground(C_SLATE);
                }
                return c;
            }
        });

        root.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel foot = new JPanel(new BorderLayout(10, 0));
        foot.setBackground(C_BG);
        foot.setBorder(new EmptyBorder(10, 20, 14, 20));

        totalLabel = new JLabel("Generate a plan to start check-in.");
        totalLabel.setFont(F_BODY); totalLabel.setForeground(C_MUTED);
        foot.add(totalLabel, BorderLayout.WEST);

        JPanel btns = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        btns.setOpaque(false);
        JButton submit  = btn("Submit Progress", C_EMERALD);
        JButton refresh = btn("Refresh Plan", C_INDIGO);
        JButton close   = btn("Close", C_MUTED);
        submit.addActionListener(e -> submit(table));
        refresh.addActionListener(e -> loadPlan());
        close.addActionListener(e -> dispose());
        btns.add(submit); btns.add(refresh); btns.add(close);
        foot.add(btns, BorderLayout.EAST);
        root.add(foot, BorderLayout.SOUTH);

        setContentPane(root);
        setVisible(true);
    }

    private void loadPlan() {
        tableModel.setRowCount(0);
        currentPlan.clear();
        totalPlanned = 0;

        List<Subject> subs = dataRepo.getSubjects();
        if (subs.isEmpty()) { JOptionPane.showMessageDialog(this,"No subjects yet - add some first."); return; }

        int hours = parent.getCalculatedStudyHours();
        if (hours <= 0) hours = 8;

        Map<Integer, Integer> plan = StudyPlanner.generatePlan(subs, hours);
        if (plan == null || plan.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "All subjects already complete or past their exam date.");
            return;
        }

        currentPlan = plan;
        for (int h : plan.values()) totalPlanned += h;

        String today = DateUtils.getCurrentDate();
        for (Subject s : subs) {
            int p = plan.getOrDefault(s.getId(), 0);
            if (p <= 0) continue;
            double prior = progressRepo.getActualHours(today, s.getId());
            tableModel.addRow(new Object[]{
                    s.getName(), p, prior,
                    String.format("%.1f", Math.max(0, p - prior)),
                    prior >= p ? "Done" : prior > 0 ? "Partial" : "Pending"
            });
        }
        refreshRemaining();
    }

    private void refreshRemaining() {
        double used = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object v = tableModel.getValueAt(i, 2);
            if (v instanceof Number) used += ((Number) v).doubleValue();
        }
        double left = Math.max(0, totalPlanned - used);
        remainingLabel.setText("Remaining: " + String.format("%.1f", left) + " / " + totalPlanned + "h");
        totalLabel.setText("Used: " + String.format("%.1f", used) + "h  |  Remaining: " + String.format("%.1f", left) + "h");

        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object plan = tableModel.getValueAt(i, 1);
            Object used2= tableModel.getValueAt(i, 2);
            if (plan == null || used2 == null) continue;
            double p = Double.parseDouble(plan.toString());
            double u = ((Number) used2).doubleValue();
            double rem = Math.max(0, p - u);
            String status = u >= p ? "Done" : u > 0 ? "Partial" : "Pending";
            tableModel.setValueAt(String.format("%.1f", rem), i, 3);
            tableModel.setValueAt(status, i, 4);
        }
    }

    private void submit(JTable table) {
        if (table.isEditing()) table.getCellEditor().stopCellEditing();

        double totalUsed = 0;
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            Object v = tableModel.getValueAt(i, 2);
            if (v instanceof Number) totalUsed += ((Number) v).doubleValue();
        }

        if (totalUsed <= 0) { JOptionPane.showMessageDialog(this,"No hours entered."); return; }
        if (totalUsed > totalPlanned) {
            JOptionPane.showMessageDialog(this,
                "Total (" + String.format("%.1f", totalUsed) + "h) exceeds planned (" + totalPlanned + "h).\n" +
                "Please reduce some entries.", "Hours Exceeded", JOptionPane.ERROR_MESSAGE);
            return;
        }

        final String today = DateUtils.getCurrentDate();
        StringBuilder summary = new StringBuilder("PROGRESS SUMMARY\n\n");

        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String name    = tableModel.getValueAt(i, 0).toString();
            double planned = Double.parseDouble(tableModel.getValueAt(i, 1).toString());
            double actual  = ((Number) tableModel.getValueAt(i, 2)).doubleValue();

            Subject s = findByName(name);
            if (s == null) continue;
            double prior = progressRepo.getActualHours(today, s.getId());
            if (actual <= 0 && prior <= 0) continue;

            double deltaHrs  = actual - prior;
            int    deltaGain = (int) Math.round(deltaHrs * StudyPlanner.PERCENT_PER_HOUR);

            int oldC = s.getCompletion();
            int newC = Math.max(0, Math.min(100, oldC + deltaGain));
            s.setCompletion(newC);
            s.setLastUpdated(today);
            dataRepo.updateSubject(s);
            progressRepo.recordProgress(today, s.getId(), planned, actual);

            double eff = planned > 0 ? (actual / planned) * 100 : 0;
            summary.append(name).append(":\n");
            summary.append("  Planned: ").append(String.format("%.1f", planned)).append("h  |  Studied: ")
                   .append(String.format("%.1f", actual)).append("h\n");
            summary.append("  Efficiency: ").append(String.format("%.0f%%", eff)).append("\n");
            summary.append("  Progress: ").append(oldC).append("% -> ").append(newC).append("%\n\n");
        }

        parent.refreshTable();
        JOptionPane.showMessageDialog(this,
            summary.toString() + "Great work today! Keep it up.",
            "Progress Saved", JOptionPane.INFORMATION_MESSAGE);
        dispose();
    }

    private Subject findByName(String name) {
        return dataRepo.getSubjects().stream()
                .filter(s -> s.getName().equals(name)).findFirst().orElse(null);
    }

    private JButton btn(String text, Color bg) {
        JButton b = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.dispose(); super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE); b.setFont(F_BOLD);
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(150, 34)); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    static class SpinnerEditor extends DefaultCellEditor {
        private JSpinner spinner;
        SpinnerEditor() {
            super(new JTextField());
            spinner = new JSpinner(new SpinnerNumberModel(0.0, 0.0, 24.0, 0.5));
            spinner.setFont(F_BODY);
        }
        public Component getTableCellEditorComponent(JTable t, Object v, boolean sel, int row, int col) {
            double max = 24;
            try {
                Object planned = t.getModel().getValueAt(row, 1);
                max = Double.parseDouble(planned.toString());
            } catch (Exception ignored) {}
            SpinnerNumberModel m = new SpinnerNumberModel(0.0, 0.0, max, 0.5);
            spinner = new JSpinner(m);
            spinner.setFont(F_BODY);
            if (v instanceof Number) spinner.setValue(((Number) v).doubleValue());
            return spinner;
        }
        public Object getCellEditorValue() { return ((Number) spinner.getValue()).doubleValue(); }
    }
}
