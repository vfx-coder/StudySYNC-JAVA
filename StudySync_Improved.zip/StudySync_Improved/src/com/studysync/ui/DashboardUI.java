package com.studysync.ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.util.*;
import java.util.List;
import com.studysync.model.Subject;
import com.studysync.repository.DataRepository;
import com.studysync.repository.ProgressRepository;
import com.studysync.utils.DateUtils;
import com.studysync.planner.StudyPlanner;
import com.studysync.core.PriorityEngine;

public class DashboardUI extends JFrame {

    static final Color C_INDIGO  = new Color(79,  70, 229);
    static final Color C_VIOLET  = new Color(109, 40, 217);
    static final Color C_EMERALD = new Color(16, 185, 129);
    static final Color C_AMBER   = new Color(245, 158, 11);
    static final Color C_ROSE    = new Color(244, 63, 94);
    static final Color C_SLATE   = new Color(15,  23, 42);
    static final Color C_STEEL   = new Color(51,  65, 85);
    static final Color C_MUTED   = new Color(100,116,139);
    static final Color C_BG      = new Color(248,250,252);
    static final Color C_CARD    = Color.WHITE;
    static final Color C_BORDER  = new Color(226,232,240);
    static final Font  F_BODY    = new Font("Segoe UI", Font.PLAIN,  13);
    static final Font  F_BOLD    = new Font("Segoe UI", Font.BOLD,   13);
    static final Font  F_TITLE   = new Font("Segoe UI", Font.BOLD,   16);
    static final Font  F_KPI_NUM = new Font("Segoe UI", Font.BOLD,   28);
    static final Font  F_KPI_LBL = new Font("Segoe UI", Font.PLAIN,  12);

    // ── state ─────────────────────────────────────────────────────────────────
    private final String             currentUser;
    private final DataRepository     dataRepo;
    private final ProgressRepository progressRepo;
    private int calculatedStudyHours = 0;
    private Map<Integer, Integer> lastPlan = new HashMap<>();

    // ── live widget refs ──────────────────────────────────────────────────────
    private DefaultTableModel subjectModel;
    private DefaultTableModel planModel;
    private JLabel kpiSubjects, kpiAvgCompletion, kpiUrgent, kpiEfficiency;
    private JLabel studyHoursLabel;
    private JTextField collegeStartF, collegeEndF, chillF, sleepF;

    // ─────────────────────────────────────────────────────────────────────────

    public DashboardUI(String username) {
        this.currentUser  = username;
        this.dataRepo     = new DataRepository(username);
        this.progressRepo = new ProgressRepository(username);
        buildUI();
        refreshAll();
    }

    public int getCalculatedStudyHours()  { return calculatedStudyHours; }

    // ── top-level frame assembly ──────────────────────────────────────────────

    private void buildUI() {
        setTitle("StudySync — " + currentUser);
        setSize(1300, 820);
        setMinimumSize(new Dimension(1100, 700));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(C_BG);
        root.add(buildSidebar(),  BorderLayout.WEST);
        root.add(buildContent(),  BorderLayout.CENTER);
        setContentPane(root);
        setVisible(true);
    }

    // ── SIDEBAR ───────────────────────────────────────────────────────────────

    private JPanel buildSidebar() {
        JPanel side = new JPanel() {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, C_VIOLET, 0, getHeight(), C_INDIGO);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.dispose();
            }
        };
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setPreferredSize(new Dimension(210, 0));

        // Brand
        JPanel brand = new JPanel(new FlowLayout(FlowLayout.CENTER));
        brand.setOpaque(false);
        brand.setBorder(new EmptyBorder(24, 0, 24, 0));
        JLabel logo = new JLabel("📚 StudySync");
        logo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        logo.setForeground(Color.WHITE);
        brand.add(logo);
        side.add(brand);

        // User pill
        JPanel userPill = new JPanel(new FlowLayout(FlowLayout.CENTER));
        userPill.setOpaque(false);
        userPill.setBorder(new EmptyBorder(0, 8, 16, 8));
        JLabel userLbl = new JLabel("👤  " + currentUser);
        userLbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        userLbl.setForeground(new Color(200, 200, 255));
        userPill.add(userLbl);
        side.add(userPill);

        // Nav items
        String[][] navItems = {
            {"📋", "Subjects",      "subjects"},
            {"📅", "Study Plan",    "plan"},
            {"✅", "Daily Check-in","checkin"},
            {"📊", "Report",        "report"}
        };
        for (String[] item : navItems) {
            side.add(navButton(item[0], item[1], item[2]));
        }

        side.add(Box.createVerticalGlue());

        // Routine Calculator section
        side.add(buildRoutineSection());

        // Logout
        JButton logout = new JButton("⇠  Logout");
        logout.setFont(new Font("Segoe UI", Font.BOLD, 13));
        logout.setForeground(new Color(255, 180, 180));
        logout.setBackground(new Color(0,0,0,0));
        logout.setContentAreaFilled(false);
        logout.setBorderPainted(false);
        logout.setFocusPainted(false);
        logout.setCursor(new Cursor(Cursor.HAND_CURSOR));
        logout.setAlignmentX(CENTER_ALIGNMENT);
        logout.addActionListener(e -> doLogout());
        JPanel logoutWrap = new JPanel(new FlowLayout(FlowLayout.CENTER));
        logoutWrap.setOpaque(false);
        logoutWrap.setBorder(new EmptyBorder(8, 0, 20, 0));
        logoutWrap.add(logout);
        side.add(logoutWrap);

        return side;
    }

    private JPanel navButton(String icon, String label, String action) {
        JPanel btn = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 10)) {
            private boolean hover = false;
            { addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { hover = true;  repaint(); }
                public void mouseExited (MouseEvent e) { hover = false; repaint(); }
                public void mouseClicked(MouseEvent e) { handleNav(action); }
              });
              setCursor(new Cursor(Cursor.HAND_CURSOR));
            }
            @Override protected void paintComponent(Graphics g) {
                if (hover) {
                    Graphics2D g2 = (Graphics2D) g.create();
                    g2.setColor(new Color(255,255,255,30));
                    g2.fillRect(0,0,getWidth(),getHeight());
                    g2.dispose();
                }
                super.paintComponent(g);
            }
        };
        btn.setOpaque(false);
        JLabel ic  = new JLabel(icon);  ic.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 16)); ic.setForeground(Color.WHITE);
        JLabel lbl = new JLabel(label); lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14)); lbl.setForeground(Color.WHITE);
        btn.add(ic); btn.add(lbl);
        return btn;
    }

    private void handleNav(String action) {
        switch (action) {
            case "checkin": new DailyCheckinUI(dataRepo, progressRepo, this); break;
            case "plan":    new StudyPlanUI(dataRepo, this); break;
            case "report":  new ReportUI(progressRepo, this); break;
            // "subjects" – already visible
        }
    }

    private JPanel buildRoutineSection() {
        JPanel p = new JPanel();
        p.setLayout(new BoxLayout(p, BoxLayout.Y_AXIS));
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(0, 12, 8, 12));

        JLabel hdr = new JLabel("Daily Routine");
        hdr.setFont(new Font("Segoe UI", Font.BOLD, 12));
        hdr.setForeground(new Color(180,180,255));
        hdr.setAlignmentX(LEFT_ALIGNMENT);
        p.add(hdr);
        p.add(Box.createVerticalStrut(8));

        JPanel grid = new JPanel(new GridLayout(4, 2, 4, 4));
        grid.setOpaque(false);
        collegeStartF = miniField("9");
        collegeEndF   = miniField("17");
        chillF        = miniField("3");
        sleepF        = miniField("7");
        grid.add(miniLabel("College start")); grid.add(collegeStartF);
        grid.add(miniLabel("College end"));   grid.add(collegeEndF);
        grid.add(miniLabel("Chill hrs"));     grid.add(chillF);
        grid.add(miniLabel("Sleep hrs"));     grid.add(sleepF);
        p.add(grid);
        p.add(Box.createVerticalStrut(6));

        JButton calc = new JButton("Calculate →");
        calc.setFont(new Font("Segoe UI", Font.BOLD, 11));
        calc.setBackground(new Color(255,255,255,40));
        calc.setForeground(Color.WHITE);
        calc.setFocusPainted(false);
        calc.setBorderPainted(false);
        calc.setContentAreaFilled(false);
        calc.setAlignmentX(LEFT_ALIGNMENT);
        calc.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calc.addActionListener(e -> calcStudyHours());
        p.add(calc);

        studyHoursLabel = new JLabel("Study hours: --");
        studyHoursLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        studyHoursLabel.setForeground(new Color(100, 255, 180));
        studyHoursLabel.setAlignmentX(LEFT_ALIGNMENT);
        p.add(studyHoursLabel);
        return p;
    }

    private JTextField miniField(String def) {
        JTextField f = new JTextField(def, 3);
        f.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        f.setBackground(new Color(255,255,255,30));
        f.setForeground(Color.WHITE);
        f.setCaretColor(Color.WHITE);
        f.setBorder(new LineBorder(new Color(255,255,255,60), 1, true));
        f.setPreferredSize(new Dimension(36, 22));
        return f;
    }
    private JLabel miniLabel(String t) {
        JLabel l = new JLabel(t);
        l.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        l.setForeground(new Color(200,200,255));
        return l;
    }

    // ── CONTENT AREA ──────────────────────────────────────────────────────────

    private JPanel buildContent() {
        JPanel p = new JPanel(new BorderLayout(0, 12));
        p.setBackground(C_BG);
        p.setBorder(new EmptyBorder(20, 20, 16, 20));

        // Top: greeting + KPI cards
        p.add(buildTopBar(),    BorderLayout.NORTH);

        // Middle: subjects table | plan table
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                                          buildSubjectsPanel(),
                                          buildPlanPanel());
        split.setDividerLocation(650);
        split.setResizeWeight(0.6);
        split.setBorder(null);
        split.setBackground(C_BG);
        p.add(split, BorderLayout.CENTER);

        // Bottom: action buttons
        p.add(buildActionBar(), BorderLayout.SOUTH);
        return p;
    }

    // top bar = greeting row + 4 KPI cards
    private JPanel buildTopBar() {
        JPanel col = new JPanel();
        col.setLayout(new BoxLayout(col, BoxLayout.Y_AXIS));
        col.setOpaque(false);

        // greeting
        JPanel greeting = new JPanel(new BorderLayout());
        greeting.setOpaque(false);
        greeting.setBorder(new EmptyBorder(0, 0, 12, 0));
        JLabel gHello = new JLabel("Good " + timeOfDay() + ", " + currentUser + " 👋");
        gHello.setFont(new Font("Segoe UI", Font.BOLD, 22));
        gHello.setForeground(C_SLATE);
        JLabel gDate  = new JLabel(DateUtils.formatDate(DateUtils.getCurrentDate()));
        gDate.setFont(F_BODY); gDate.setForeground(C_MUTED);
        greeting.add(gHello, BorderLayout.WEST);
        greeting.add(gDate,  BorderLayout.EAST);
        col.add(greeting);

        // KPI row
        JPanel kpi = new JPanel(new GridLayout(1, 4, 12, 0));
        kpi.setOpaque(false);
        kpiSubjects      = new JLabel("0");
        kpiAvgCompletion = new JLabel("0%");
        kpiUrgent        = new JLabel("0");
        kpiEfficiency    = new JLabel("0%");
        kpi.add(kpiCard("Total Subjects", kpiSubjects,   C_INDIGO,  "📚"));
        kpi.add(kpiCard("Avg Completion",  kpiAvgCompletion, C_EMERALD, "📈"));
        kpi.add(kpiCard("Urgent (≤3 days)", kpiUrgent,   C_ROSE,    "🔥"));
        kpi.add(kpiCard("Weekly Efficiency", kpiEfficiency, C_AMBER, "⚡"));
        col.add(kpi);
        return col;
    }

    private JPanel kpiCard(String title, JLabel valueLabel, Color accent, String emoji) {
        JPanel card = new JPanel(new BorderLayout(8, 4));
        card.setBackground(C_CARD);
        card.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(C_BORDER, 1, true),
            new EmptyBorder(14, 16, 14, 16)));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel em = new JLabel(emoji);
        em.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 20));
        JLabel strip = new JLabel();
        strip.setOpaque(true);
        strip.setBackground(accent);
        strip.setPreferredSize(new Dimension(4, 0));
        top.add(em, BorderLayout.WEST);

        JLabel titleLbl = new JLabel(title);
        titleLbl.setFont(F_KPI_LBL);
        titleLbl.setForeground(C_MUTED);
        card.add(titleLbl, BorderLayout.NORTH);

        valueLabel.setFont(F_KPI_NUM);
        valueLabel.setForeground(accent);
        card.add(valueLabel, BorderLayout.CENTER);

        return card;
    }

    // Subjects table panel
    private JPanel buildSubjectsPanel() {
        JPanel p = card("📋  Subjects");

        String[] cols = {"ID","Subject","Difficulty","Completion","Days Left","Updated"};
        subjectModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = styledTable(subjectModel);

        // Progress bar renderer for completion column
        table.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(
                    JTable t, Object val, boolean sel, boolean foc, int row, int col) {
                String s = (val == null) ? "0%" : val.toString();
                int pct = 0;
                try { pct = Integer.parseInt(s.replace("%","").trim()); } catch (Exception ignored) {}
                JProgressBar bar = new JProgressBar(0, 100);
                bar.setValue(pct);
                bar.setStringPainted(true);
                bar.setString(pct + "%");
                bar.setForeground(pct >= 80 ? C_EMERALD : pct >= 50 ? C_AMBER : C_ROSE);
                bar.setBackground(new Color(226,232,240));
                bar.setBorder(new EmptyBorder(3, 4, 3, 4));
                return bar;
            }
        });

        // Alternating rows
        table.setDefaultRenderer(Object.class, new AlternatingRowRenderer(subjectModel));
        // Override col 3
        table.getColumnModel().getColumn(3).setCellRenderer(new ProgressBarRenderer());

        p.add(new JScrollPane(table), BorderLayout.CENTER);
        return p;
    }

    // Plan table panel
    private JPanel buildPlanPanel() {
        JPanel p = card("📅  Smart Study Plan");

        String[] cols = {"Subject","Hours","Progress","Priority"};
        planModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c) { return false; }
        };
        JTable table = styledTable(planModel);

        // Colour-code Priority column
        table.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                String s = v == null ? "" : v.toString();
                if (!sel) {
                    c.setForeground(s.contains("High")   ? C_ROSE :
                                    s.contains("Medium") ? C_AMBER : C_EMERALD);
                }
                return c;
            }
        });

        p.add(new JScrollPane(table), BorderLayout.CENTER);

        // "Generate Plan" inside the panel
        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 8));
        btnRow.setBackground(C_CARD);
        JButton gen = styledBtn("⚡ Generate Plan", C_INDIGO);
        gen.addActionListener(e -> new StudyPlanUI(dataRepo, this));
        btnRow.add(gen);
        p.add(btnRow, BorderLayout.SOUTH);

        return p;
    }

    // Action bar at the bottom
    private JPanel buildActionBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 6));
        bar.setBackground(C_CARD);
        bar.setBorder(BorderFactory.createCompoundBorder(
            new MatteBorder(1,0,0,0, C_BORDER),
            new EmptyBorder(8, 0, 6, 0)));

        bar.add(styledBtn("➕  Add Subject",    C_EMERALD, e -> new AddSubjectUI(dataRepo, this)));
        bar.add(styledBtn("✏️  Edit Subject",   C_AMBER,   e -> editSubject()));
        bar.add(styledBtn("🗑️  Delete Subject", C_ROSE,    e -> deleteSubject()));
        bar.add(styledBtn("✅  Daily Check-in", C_INDIGO,  e -> new DailyCheckinUI(dataRepo, progressRepo, this)));
        bar.add(styledBtn("📊  Weekly Report",  C_VIOLET,  e -> new ReportUI(progressRepo, this)));
        return bar;
    }

    // ── helpers: card container ───────────────────────────────────────────────

    private JPanel card(String title) {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(C_CARD);
        p.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(C_BORDER, 1, true),
            new EmptyBorder(12, 12, 8, 12)));
        JLabel tl = new JLabel(title);
        tl.setFont(F_TITLE); tl.setForeground(C_SLATE);
        tl.setBorder(new EmptyBorder(0, 0, 6, 0));
        p.add(tl, BorderLayout.NORTH);
        return p;
    }

    private JTable styledTable(DefaultTableModel model) {
        JTable t = new JTable(model);
        t.setRowHeight(32);
        t.setFont(F_BODY);
        t.setGridColor(C_BORDER);
        t.setSelectionBackground(new Color(224, 231, 255));
        t.setSelectionForeground(C_SLATE);
        t.setShowVerticalLines(false);
        JTableHeader h = t.getTableHeader();
        h.setFont(F_BOLD);
        h.setBackground(C_SLATE);
        h.setForeground(Color.WHITE);
        h.setPreferredSize(new Dimension(0, 34));
        h.setReorderingAllowed(false);
        return t;
    }

    private JButton styledBtn(String text, Color bg, ActionListener al) {
        JButton b = styledBtn(text, bg);
        b.addActionListener(al);
        return b;
    }
    private JButton styledBtn(String text, Color bg) {
        JButton b = new JButton(text) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? bg.darker() :
                            getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE);
        b.setFont(new Font("Segoe UI", Font.BOLD, 12));
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(140, 34));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ── public update methods ─────────────────────────────────────────────────

    public void refreshTable() {
        subjectModel.setRowCount(0);
        for (Subject s : dataRepo.getSubjects()) {
            subjectModel.addRow(new Object[]{
                s.getId(), s.getName(),
                diffStr(s.getDifficulty()),
                s.getCompletion() + "%",
                s.getDaysLeft(),
                s.getLastUpdated()
            });
        }
        updateKPIs();
    }

    public void updatePlanTable(Map<Integer, Integer> plan, List<Subject> subjects, int totalHours) {
        planModel.setRowCount(0);
        lastPlan = plan;
        int total = 0;
        for (Subject s : subjects) {
            int h = plan.getOrDefault(s.getId(), 0);
            if (h <= 0) continue;
            total += h;
            int after = Math.min(100, s.getCompletion() + h * 10);
            double pri = PriorityEngine.calculatePriority(s);
            String priLabel = pri >= 70 ? "🔴 High" : pri >= 40 ? "🟡 Medium" : "🟢 Low";
            planModel.addRow(new Object[]{s.getName(), h + "h",
                    s.getCompletion() + "% → " + after + "%", priLabel});
        }
        planModel.addRow(new Object[]{"─────────────","──────","──────────────","──────"});
        planModel.addRow(new Object[]{"TOTAL", total + "/" + totalHours + "h", "", ""});
    }

    // kept for DailyCheckinUI / StudyPlanUI
    public void updateStudyPlanTable(Map<Integer, Integer> plan, List<Subject> subjects, int totalHours) {
        updatePlanTable(plan, subjects, totalHours);
    }

    // ── private actions ───────────────────────────────────────────────────────

    private void refreshAll() { refreshTable(); }

    private void updateKPIs() {
        List<Subject> subs = dataRepo.getSubjects();
        kpiSubjects.setText(String.valueOf(subs.size()));

        double avg = subs.stream().mapToInt(Subject::getCompletion).average().orElse(0);
        kpiAvgCompletion.setText(String.format("%.0f%%", avg));

        long urgent = subs.stream().filter(s -> s.getDaysLeft() <= 3 && s.getCompletion() < 100).count();
        kpiUrgent.setText(String.valueOf(urgent));

        double eff = progressRepo.getWeeklyEfficiency();
        kpiEfficiency.setText(String.format("%.0f%%", eff));
    }

    private void calcStudyHours() {
        try {
            int cs = Integer.parseInt(collegeStartF.getText().trim());
            int ce = Integer.parseInt(collegeEndF.getText().trim());
            int ch = Integer.parseInt(chillF.getText().trim());
            int sl = Integer.parseInt(sleepF.getText().trim());
            int college = ce - cs; if (college < 0) college += 24;
            calculatedStudyHours = Math.max(0, 24 - college - ch - sl);
            studyHoursLabel.setText("Study hours: " + calculatedStudyHours);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Enter valid numbers in all routine fields.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void editSubject() {
        int row = getSubjectTable().getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select a subject to edit."); return; }
        int id = (int) subjectModel.getValueAt(row, 0);
        Subject s = dataRepo.findById(id);
        if (s == null) return;

        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        JTextField nameF = new JTextField(s.getName());
        JComboBox<Integer> diffBox = new JComboBox<>(new Integer[]{1,2,3,4,5});
        diffBox.setSelectedItem(s.getDifficulty());
        JTextField compF = new JTextField(String.valueOf(s.getCompletion()));
        JTextField daysF = new JTextField(String.valueOf(s.getDaysLeft()));
        form.add(new JLabel("Name:")); form.add(nameF);
        form.add(new JLabel("Difficulty:")); form.add(diffBox);
        form.add(new JLabel("Completion (0-100):")); form.add(compF);
        form.add(new JLabel("Days Left:")); form.add(daysF);

        int res = JOptionPane.showConfirmDialog(this, form, "Edit: " + s.getName(),
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (res != JOptionPane.OK_OPTION) return;
        try {
            int comp = Integer.parseInt(compF.getText().trim());
            int days = Integer.parseInt(daysF.getText().trim());
            if (comp < 0 || comp > 100) { JOptionPane.showMessageDialog(this,"Completion must be 0-100."); return; }
            if (days < 0)               { JOptionPane.showMessageDialog(this,"Days must be ≥ 0."); return; }
            s.setName(nameF.getText().trim());
            s.setDifficulty((Integer) diffBox.getSelectedItem());
            s.setCompletion(comp);
            s.setDaysLeft(days);
            s.setLastUpdated(DateUtils.getCurrentDate());
            dataRepo.updateSubject(s);
            refreshTable();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid number entered.");
        }
    }

    private void deleteSubject() {
        int row = getSubjectTable().getSelectedRow();
        if (row < 0) { JOptionPane.showMessageDialog(this,"Select a subject to delete."); return; }
        int id   = (int) subjectModel.getValueAt(row, 0);
        String nm = (String) subjectModel.getValueAt(row, 1);
        int ok = JOptionPane.showConfirmDialog(this, "Delete \"" + nm + "\"?", "Confirm Delete",
                JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (ok == JOptionPane.YES_OPTION) { dataRepo.deleteSubject(id); refreshTable(); }
    }

    private void doLogout() {
        int ok = JOptionPane.showConfirmDialog(this,"Logout?","Logout",JOptionPane.YES_NO_OPTION);
        if (ok == JOptionPane.YES_OPTION) { dispose(); SwingUtilities.invokeLater(LoginUI::new); }
    }

    // cache the JTable reference for selection
    private JTable _subjectTable;
    private JTable getSubjectTable() {
        if (_subjectTable == null) {
            // find it by traversing the component tree lazily
            _subjectTable = findTable(getContentPane(), subjectModel);
        }
        return _subjectTable;
    }
    private JTable findTable(Container c, TableModel model) {
        for (Component comp : c.getComponents()) {
            if (comp instanceof JScrollPane) {
                Component v = ((JScrollPane)comp).getViewport().getView();
                if (v instanceof JTable && ((JTable)v).getModel() == model) return (JTable) v;
            }
            if (comp instanceof Container) {
                JTable t = findTable((Container)comp, model);
                if (t != null) return t;
            }
        }
        return null;
    }

    // ── small helpers ─────────────────────────────────────────────────────────

    private String diffStr(int d) {
        return switch (d) {
            case 1 -> "Very Easy";
            case 2 -> "Easy";
            case 3 -> "Medium";
            case 4 -> "Hard";
            case 5 -> "Very Hard";
            default -> "?";
        };
    }

    private String timeOfDay() {
        int h = java.time.LocalTime.now().getHour();
        if (h < 12) return "morning";
        if (h < 17) return "afternoon";
        return "evening";
    }

    // ── custom renderers ──────────────────────────────────────────────────────

    static class AlternatingRowRenderer extends DefaultTableCellRenderer {
        private final TableModel model;
        AlternatingRowRenderer(TableModel m) { model = m; }
        public Component getTableCellRendererComponent(JTable t, Object v,
                boolean sel, boolean foc, int row, int col) {
            Component c = super.getTableCellRendererComponent(t,v,sel,foc,row,col);
            if (!sel) c.setBackground(row % 2 == 0 ? Color.WHITE : new Color(248,250,252));
            c.setForeground(C_SLATE);
            return c;
        }
    }

    static class ProgressBarRenderer extends JProgressBar implements TableCellRenderer {
        ProgressBarRenderer() {
            super(0, 100);
            setStringPainted(true);
            setBorder(new EmptyBorder(4, 6, 4, 6));
        }
        public Component getTableCellRendererComponent(JTable t, Object v,
                boolean sel, boolean foc, int row, int col) {
            String s = (v == null) ? "0%" : v.toString();
            int pct  = 0;
            try { pct = Integer.parseInt(s.replace("%","").trim()); } catch (Exception ignored) {}
            setValue(pct);
            setString(pct + "%");
            setForeground(pct >= 80 ? C_EMERALD : pct >= 50 ? C_AMBER : C_ROSE);
            setBackground(new Color(241,245,249));
            return this;
        }
    }
}
