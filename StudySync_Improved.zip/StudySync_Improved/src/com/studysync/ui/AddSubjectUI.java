package com.studysync.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import com.studysync.model.Subject;
import com.studysync.repository.DataRepository;
import com.studysync.utils.DateUtils;

import static com.studysync.ui.DashboardUI.*;

public class AddSubjectUI extends JDialog {

    private final DataRepository dataRepo;
    private final DashboardUI    parent;
    private JTextField     nameField;
    private JComboBox<String> diffBox;
    private JSlider        completionSlider;
    private JLabel         completionLbl;
    private JTextField     daysField;
    private JLabel         errorLbl;

    public AddSubjectUI(DataRepository dataRepo, DashboardUI parent) {
        super(parent, "Add New Subject", true);
        this.dataRepo = dataRepo;
        this.parent   = parent;
        buildUI();
    }

    private void buildUI() {
        setSize(420, 420);
        setLocationRelativeTo(parent);
        setResizable(false);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        JPanel header = new JPanel();
        header.setBackground(C_INDIGO);
        header.setPreferredSize(new Dimension(0, 56));
        header.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 14));
        JLabel title = new JLabel("New Subject");
        title.setFont(new Font("Segoe UI", Font.BOLD, 16));
        title.setForeground(Color.WHITE);
        header.add(title);
        root.add(header, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(new EmptyBorder(20, 30, 10, 30));
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.fill = GridBagConstraints.HORIZONTAL; g.insets = new Insets(5,0,5,0);

        g.gridy = 0; form.add(label("Subject Name"), g);
        g.gridy = 1;
        nameField = new JTextField();
        styleField(nameField);
        form.add(nameField, g);

        g.gridy = 2; form.add(label("Difficulty"), g);
        g.gridy = 3;
        diffBox = new JComboBox<>(new String[]{
                "1 - Very Easy","2 - Easy","3 - Medium","4 - Hard","5 - Very Hard"});
        diffBox.setFont(F_BODY);
        form.add(diffBox, g);

        g.gridy = 4;
        JPanel compRow = new JPanel(new BorderLayout(8, 0));
        compRow.setOpaque(false);
        compRow.add(label("Completion"), BorderLayout.WEST);
        completionLbl = new JLabel("0%");
        completionLbl.setFont(F_BOLD); completionLbl.setForeground(C_INDIGO);
        compRow.add(completionLbl, BorderLayout.EAST);
        form.add(compRow, g);

        g.gridy = 5;
        completionSlider = new JSlider(0, 100, 0);
        completionSlider.setPaintTicks(true);
        completionSlider.setMajorTickSpacing(25);
        completionSlider.setPaintLabels(true);
        completionSlider.setBackground(Color.WHITE);
        completionSlider.addChangeListener(e -> completionLbl.setText(completionSlider.getValue() + "%"));
        form.add(completionSlider, g);

        g.gridy = 6; form.add(label("Days Left for Exam"), g);
        g.gridy = 7;
        daysField = new JTextField();
        styleField(daysField);
        form.add(daysField, g);

        g.gridy = 8;
        errorLbl = new JLabel(" ");
        errorLbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        errorLbl.setForeground(C_ROSE);
        form.add(errorLbl, g);

        root.add(form, BorderLayout.CENTER);

        JPanel btnRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        btnRow.setBackground(Color.WHITE);
        btnRow.setBorder(new MatteBorder(1, 0, 0, 0, C_BORDER));

        JButton save   = gradientBtn("Save Subject", C_EMERALD);
        JButton cancel = gradientBtn("Cancel", C_MUTED);
        save.addActionListener(e -> save());
        cancel.addActionListener(e -> dispose());
        btnRow.add(save); btnRow.add(cancel);
        root.add(btnRow, BorderLayout.SOUTH);

        setContentPane(root);
        setVisible(true);
        nameField.requestFocusInWindow();
    }

    private void save() {
        String name = nameField.getText().trim();
        if (name.isEmpty()) { errorLbl.setText("Subject name is required."); return; }
        if (name.length() > 40) { errorLbl.setText("Name must be at most 40 characters."); return; }

        for (Subject existing : dataRepo.getSubjects()) {
            if (existing.getName().equalsIgnoreCase(name)) {
                errorLbl.setText("A subject with that name already exists.");
                return;
            }
        }

        int difficulty = diffBox.getSelectedIndex() + 1;
        int completion = completionSlider.getValue();
        int daysLeft;
        try {
            daysLeft = Integer.parseInt(daysField.getText().trim());
            if (daysLeft <= 0)  { errorLbl.setText("Days left must be > 0."); return; }
            if (daysLeft > 365) { errorLbl.setText("Days left must be at most 365."); return; }
        } catch (NumberFormatException ex) {
            errorLbl.setText("Enter a valid number for days left."); return;
        }

        int id = dataRepo.nextNewId();
        Subject s = new Subject(id, name, difficulty, completion, daysLeft, DateUtils.getCurrentDate());
        dataRepo.addSubject(s);
        parent.refreshTable();
        dispose();
        JOptionPane.showMessageDialog(parent, "Subject \"" + name + "\" added!", "Done",
                JOptionPane.INFORMATION_MESSAGE);
    }

    private JLabel label(String t) {
        JLabel l = new JLabel(t);
        l.setFont(F_BOLD); l.setForeground(C_STEEL);
        return l;
    }

    private void styleField(JTextField f) {
        f.setFont(F_BODY);
        f.setPreferredSize(new Dimension(0, 34));
        f.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(C_BORDER, 1, true),
            new EmptyBorder(5, 8, 5, 8)));
    }

    private JButton gradientBtn(String text, Color bg) {
        JButton b = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE);
        b.setFont(F_BOLD);
        b.setContentAreaFilled(false);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(130, 36));
        b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }
}
