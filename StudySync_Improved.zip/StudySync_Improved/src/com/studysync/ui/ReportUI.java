package com.studysync.ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.geom.*;
import java.time.LocalDate;
import java.time.format.TextStyle;
import java.util.*;
import com.studysync.repository.ProgressRepository;

import static com.studysync.ui.DashboardUI.*;

public class ReportUI extends JDialog {

    private final ProgressRepository progressRepo;
    private DefaultTableModel tableModel;
    private JLabel summaryLabel, feedbackLabel, avgLabel;
    private BarChartPanel chartPanel;

    private final String[] dates      = new String[7];
    private final String[] dayNames   = new String[7];
    private final double[] efficiency = new double[7];

    public ReportUI(ProgressRepository progressRepo, DashboardUI parent) {
        super(parent, "Weekly Progress Report", true);
        this.progressRepo = progressRepo;
        buildUI();
        loadReport();
    }

    private void buildUI() {
        setSize(750, 660);
        setLocationRelativeTo(getOwner());

        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(C_BG);

        // header
        JPanel header = new JPanel(new BorderLayout()) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setPaint(new GradientPaint(0,0,C_VIOLET,getWidth(),0,C_INDIGO));
                g2.fillRect(0,0,getWidth(),getHeight());
                g2.dispose();
            }
        };
        header.setPreferredSize(new Dimension(0,70));
        header.setBorder(new EmptyBorder(14,24,14,24));
        JLabel title = new JLabel("  Weekly Progress Report");
        title.setFont(new Font("Segoe UI", Font.BOLD, 20));
        title.setForeground(Color.WHITE);
        header.add(title, BorderLayout.WEST);
        JPanel avgWrap = new JPanel(new GridLayout(2,1,0,2));
        avgWrap.setOpaque(false);
        avgLabel = new JLabel("Weekly Avg: --", SwingConstants.RIGHT);
        avgLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        avgLabel.setForeground(Color.WHITE);
        JLabel weekRange = new JLabel(
            LocalDate.now().minusDays(6) + " to " + LocalDate.now(), SwingConstants.RIGHT);
        weekRange.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        weekRange.setForeground(new Color(200,200,255));
        avgWrap.add(avgLabel); avgWrap.add(weekRange);
        header.add(avgWrap, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // centre: chart + table + summary
        JPanel centre = new JPanel(new BorderLayout(0,10));
        centre.setBackground(C_BG);
        centre.setBorder(new EmptyBorder(12,16,8,16));

        chartPanel = new BarChartPanel();
        chartPanel.setPreferredSize(new Dimension(0,185));
        chartPanel.setBackground(C_CARD);
        chartPanel.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(C_BORDER,1,true),
            new EmptyBorder(10,18,8,18)));
        centre.add(chartPanel, BorderLayout.NORTH);

        String[] cols = {"Date","Day","Efficiency","Status","Studied"};
        tableModel = new DefaultTableModel(cols, 0) {
            public boolean isCellEditable(int r, int c){ return false; }
        };
        JTable table = new JTable(tableModel);
        table.setRowHeight(32); table.setFont(F_BODY);
        table.setGridColor(C_BORDER); table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(224,231,255));
        JTableHeader th = table.getTableHeader();
        th.setFont(F_BOLD); th.setBackground(C_SLATE); th.setForeground(Color.WHITE);
        th.setPreferredSize(new Dimension(0,34)); th.setReorderingAllowed(false);

        table.getColumnModel().getColumn(2).setCellRenderer(new TableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                String s = v == null ? "0%" : v.toString();
                double pct = 0;
                try { pct = Double.parseDouble(s.replace("%","").trim()); } catch (Exception e){}
                JProgressBar bar = new JProgressBar(0,100);
                bar.setValue((int)pct); bar.setStringPainted(true); bar.setString(s);
                bar.setForeground(pct>=80?C_EMERALD:pct>=60?new Color(52,211,153):pct>=40?C_AMBER:pct>0?C_ROSE:C_BORDER);
                bar.setBackground(new Color(241,245,249));
                bar.setBorder(new EmptyBorder(4,6,4,6));
                return bar;
            }
        });

        table.getColumnModel().getColumn(3).setCellRenderer(new DefaultTableCellRenderer() {
            public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t,v,sel,foc,row,col);
                String s = v == null ? "" : v.toString();
                if (!sel) {
                    if      (s.equals("Excellent"))         { c.setForeground(C_EMERALD); c.setBackground(new Color(240,255,248)); }
                    else if (s.equals("Good"))               { c.setForeground(C_INDIGO);  c.setBackground(new Color(238,242,255)); }
                    else if (s.equals("Average"))            { c.setForeground(C_AMBER);   c.setBackground(new Color(255,251,235)); }
                    else if (s.equals("Needs Improvement"))  { c.setForeground(C_ROSE);    c.setBackground(new Color(255,241,242)); }
                    else                                     { c.setForeground(C_MUTED);   c.setBackground(new Color(248,250,252)); }
                }
                return c;
            }
        });

        centre.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel summCard = new JPanel(new GridLayout(2,1,0,4));
        summCard.setBackground(C_CARD);
        summCard.setBorder(BorderFactory.createCompoundBorder(
            new LineBorder(C_BORDER,1,true), new EmptyBorder(12,18,12,18)));
        summaryLabel = new JLabel("--", SwingConstants.CENTER);
        summaryLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
        summaryLabel.setForeground(C_SLATE);
        feedbackLabel = new JLabel("--", SwingConstants.CENTER);
        feedbackLabel.setFont(F_BODY); feedbackLabel.setForeground(C_MUTED);
        summCard.add(summaryLabel); summCard.add(feedbackLabel);
        centre.add(summCard, BorderLayout.SOUTH);

        root.add(centre, BorderLayout.CENTER);

        JPanel foot = new JPanel(new FlowLayout(FlowLayout.RIGHT,12,10));
        foot.setBackground(C_BG);
        foot.setBorder(new MatteBorder(1,0,0,0,C_BORDER));
        JButton ref = btn("Refresh", C_INDIGO);
        JButton cls = btn("Close",   C_MUTED);
        ref.addActionListener(e -> loadReport());
        cls.addActionListener(e -> dispose());
        foot.add(ref); foot.add(cls);
        root.add(foot, BorderLayout.SOUTH);

        setContentPane(root);
        setVisible(true);
    }

    private void loadReport() {
        tableModel.setRowCount(0);
        LocalDate today = LocalDate.now();
        double total = 0; int cnt = 0;
        for (int i = 0; i < 7; i++) {
            LocalDate d = today.minusDays(6 - i);
            dates[i]    = d.toString();
            dayNames[i] = d.getDayOfWeek().getDisplayName(TextStyle.SHORT, Locale.ENGLISH);
            efficiency[i] = progressRepo.getDailyEfficiency(dates[i]);
            if (efficiency[i] > 0 || progressRepo.hasDataForDate(dates[i])) { total += efficiency[i]; cnt++; }
            double hrs = actualHours(dates[i]);
            tableModel.addRow(new Object[]{
                dates[i],
                d.getDayOfWeek().getDisplayName(TextStyle.FULL, Locale.ENGLISH),
                String.format("%.1f%%", efficiency[i]),
                progressRepo.statusLabel(efficiency[i]),
                hrs > 0 ? String.format("%.1fh", hrs) : "—"
            });
        }
        double avg = cnt > 0 ? total/cnt : 0;
        avgLabel.setText(String.format("Weekly Avg: %.1f%%", avg));
        summaryLabel.setText(String.format("%.1f%% average  ·  %d / 7 days studied", avg, cnt));
        feedbackLabel.setText(feedback(avg));
        chartPanel.repaint();
    }

    private double actualHours(String date) {
        var pd = progressRepo.getProgressData().get(date);
        if (pd == null) return 0;
        return pd.values().stream().mapToDouble(p -> p.actualHours).sum();
    }

    private String feedback(double avg) {
        if (avg >= 80) return "Excellent! You're crushing your study goals.";
        if (avg >= 60) return "Good work! Stay consistent and you'll ace it.";
        if (avg >= 40) return "Average. Try to stick closer to your study plan.";
        if (avg >  0)  return "Needs improvement. Follow the generated plan daily.";
        return "No data yet. Use Daily Check-in to record your progress!";
    }

    private JButton btn(String text, Color bg) {
        JButton b = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0,0,getWidth(),getHeight(),8,8);
                g2.dispose(); super.paintComponent(g);
            }
        };
        b.setForeground(Color.WHITE); b.setFont(F_BOLD);
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(110,34)); b.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ── Bar chart ─────────────────────────────────────────────────────────────
    class BarChartPanel extends JPanel {
        BarChartPanel() { setOpaque(true); }
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int w=getWidth(), h=getHeight();
            int pL=44, pR=12, pT=18, pB=34;
            int cW=w-pL-pR, cH=h-pT-pB;

            // grid
            g2.setFont(new Font("Segoe UI",Font.PLAIN,10));
            g2.setStroke(new BasicStroke(1,BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER,1f,new float[]{4,4},0));
            for (int pct : new int[]{0,25,50,75,100}) {
                int y = pT + cH - (int)(pct/100.0*cH);
                g2.setColor(new Color(226,232,240));
                g2.drawLine(pL,y,pL+cW,y);
                g2.setColor(C_MUTED);
                g2.drawString(pct+"%", 2, y+4);
            }

            // bars
            g2.setStroke(new BasicStroke(1));
            int barW = cW*55/(100*7), gap=(cW - 7*barW)/8;
            for (int i=0; i<7; i++) {
                double eff = efficiency[i];
                int bH = (int)(eff/100.0*cH);
                int x  = pL + gap + i*(barW+gap);
                Color top = eff>=80?C_EMERALD:eff>=60?new Color(52,211,153):eff>=40?C_AMBER:eff>0?C_ROSE:new Color(226,232,240);
                if (bH > 0) {
                    g2.setPaint(new GradientPaint(x,pT+cH-bH,top,x,pT+cH,top.darker()));
                    g2.fillRoundRect(x,pT+cH-bH,barW,bH,6,6);
                    g2.setFont(new Font("Segoe UI",Font.BOLD,9));
                    g2.setColor(top.darker());
                    String val = String.format("%.0f%%",eff);
                    int vx = x+barW/2-g2.getFontMetrics().stringWidth(val)/2;
                    g2.drawString(val, vx, Math.max(pT+10, pT+cH-bH-3));
                } else {
                    g2.setColor(new Color(241,245,249));
                    g2.fillRoundRect(x,pT+cH-4,barW,4,4,4);
                }
                String dn = dayNames[i] != null ? dayNames[i] : "";
                g2.setFont(new Font("Segoe UI",Font.BOLD,10));
                g2.setColor(C_SLATE);
                int lx = x+barW/2-g2.getFontMetrics().stringWidth(dn)/2;
                g2.drawString(dn, lx, pT+cH+14);
            }

            // axes
            g2.setStroke(new BasicStroke(1.5f));
            g2.setColor(C_STEEL);
            g2.drawLine(pL,pT,pL,pT+cH);
            g2.drawLine(pL,pT+cH,pL+cW,pT+cH);
            g2.dispose();
        }
    }
}
