package com.studysync.ui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import com.studysync.auth.AuthService;

public class LoginUI extends JFrame {

    static final Color C_INDIGO = new Color(79, 70, 229);
    static final Color C_VIOLET = new Color(109, 40, 217);
    static final Color C_EMERALD = new Color(16, 185, 129);
    static final Color C_ROSE = new Color(244, 63, 94);
    static final Color C_SLATE = new Color(15, 23, 42);
    static final Color C_MUTED = new Color(100, 116, 139);
    static final Color C_BG = new Color(248, 250, 252);
    static final Color C_WHITE = Color.WHITE;
    static final Font F_TITLE = new Font("Segoe UI", Font.BOLD, 28);
    static final Font F_SUBTITLE = new Font("Segoe UI", Font.PLAIN, 14);
    static final Font F_LABEL = new Font("Segoe UI", Font.BOLD, 12);
    static final Font F_BODY = new Font("Segoe UI", Font.PLAIN, 13);
    static final Font F_BRAND = new Font("Segoe UI", Font.BOLD, 42);
    static final Font F_TAGLINE = new Font("Segoe UI", Font.ITALIC, 16);

    private final AuthService authService = new AuthService();
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JLabel errorLabel;
    private JButton loginBtn;

    private JTextField signupUser;
    private JPasswordField signupPass;
    private JPasswordField signupConfirm;
    private JLabel signupError;
    private JButton signupBtn;

    private JPanel cardPanel;
    private CardLayout cards;

    public LoginUI() {
        initUI();
    }

    private void initUI() {
        setTitle("StudySync - Smart Planner");
        setSize(900, 560);
        setMinimumSize(new Dimension(800, 500));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(C_SLATE);

        root.add(buildHeroPanel(), BorderLayout.WEST);

        cards = new CardLayout();
        cardPanel = new JPanel(cards);
        cardPanel.setBackground(C_BG);
        cardPanel.add(buildLoginCard(), "login");
        cardPanel.add(buildSignupCard(), "signup");
        root.add(cardPanel, BorderLayout.CENTER);

        setContentPane(root);
        setVisible(true);

        SwingUtilities.invokeLater(() -> {
            getRootPane().setDefaultButton(loginBtn);
            usernameField.requestFocusInWindow();
        });
    }

    private JPanel buildHeroPanel() {
        JPanel hero = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                GradientPaint gp = new GradientPaint(0, 0, C_VIOLET, 0, getHeight(), C_INDIGO);
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.12f));
                g2.setColor(Color.WHITE);
                g2.fillOval(-60, -60, 280, 280);
                g2.fillOval(getWidth() - 120, getHeight() - 120, 240, 240);
                g2.dispose();
            }
        };
        hero.setPreferredSize(new Dimension(340, 0));
        hero.setOpaque(false);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.gridy = GridBagConstraints.RELATIVE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(6, 20, 6, 20);

        JLabel brand = new JLabel("StudySync");
        brand.setFont(F_BRAND);
        brand.setForeground(C_WHITE);
        hero.add(brand, gbc);

        JLabel tag = new JLabel("<html><center>Study smarter.<br/>Achieve more.</center></html>");
        tag.setFont(F_TAGLINE);
        tag.setForeground(new Color(200, 200, 255));
        tag.setHorizontalAlignment(SwingConstants.CENTER);
        hero.add(tag, gbc);

        String[] feats = { "AI-powered priority planner",
                "Daily check-in & tracking",
                "Weekly progress reports" };
        gbc.insets = new Insets(4, 24, 2, 24);
        for (String f : feats) {
            JLabel lbl = new JLabel("•  " + f);
            lbl.setFont(new Font("Segoe UI", Font.PLAIN, 13));
            lbl.setForeground(new Color(200, 210, 255));
            hero.add(lbl, gbc);
        }
        return hero;
    }

    private JPanel buildLoginCard() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(C_BG);
        card.setBorder(new EmptyBorder(0, 50, 0, 50));
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(6, 0, 6, 0);

        g.gridy = 0;
        JLabel h = new JLabel("Welcome back");
        h.setFont(F_TITLE);
        h.setForeground(C_SLATE);
        card.add(h, g);

        g.gridy = 1;
        JLabel sub = new JLabel("Sign in to your account");
        sub.setFont(F_SUBTITLE);
        sub.setForeground(C_MUTED);
        card.add(sub, g);

        g.gridy = 2;
        g.insets = new Insets(18, 0, 4, 0);
        card.add(makeLabel("Username"), g);

        g.gridy = 3;
        g.insets = new Insets(0, 0, 6, 0);
        usernameField = styledField(20);
        card.add(usernameField, g);

        g.gridy = 4;
        g.insets = new Insets(6, 0, 4, 0);
        card.add(makeLabel("Password"), g);

        g.gridy = 5;
        g.insets = new Insets(0, 0, 6, 0);
        passwordField = styledPassField(20);
        card.add(passwordField, g);

        g.gridy = 6;
        errorLabel = new JLabel(" ");
        errorLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        errorLabel.setForeground(C_ROSE);
        card.add(errorLabel, g);

        g.gridy = 7;
        g.insets = new Insets(4, 0, 10, 0);
        loginBtn = primaryButton("Sign In", C_INDIGO);
        loginBtn.addActionListener(e -> doLogin());
        card.add(loginBtn, g);
        usernameField.addActionListener(e -> passwordField.requestFocusInWindow());
        passwordField.addActionListener(e -> doLogin());

        g.gridy = 8;
        g.insets = new Insets(0, 0, 0, 0);
        JPanel switchRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        switchRow.setBackground(C_BG);
        JLabel q = new JLabel("Don't have an account?");
        q.setFont(F_BODY);
        q.setForeground(C_MUTED);
        JLabel link = linkLabel("Sign up");
        link.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                showCard("signup");
            }
        });
        switchRow.add(q);
        switchRow.add(link);
        card.add(switchRow, g);

        return card;
    }

    private void showCard(String name) {
        cards.show(cardPanel, name);
        SwingUtilities.invokeLater(() -> {
            if ("login".equals(name)) {
                getRootPane().setDefaultButton(loginBtn);
                usernameField.requestFocusInWindow();
            } else {
                getRootPane().setDefaultButton(signupBtn);
                signupUser.requestFocusInWindow();
            }
        });
    }

    private JPanel buildSignupCard() {
        JPanel card = new JPanel(new GridBagLayout());
        card.setBackground(C_BG);
        card.setBorder(new EmptyBorder(0, 50, 0, 50));
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0;
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(5, 0, 5, 0);

        g.gridy = 0;
        JLabel h = new JLabel("Create Account");
        h.setFont(F_TITLE);
        h.setForeground(C_SLATE);
        card.add(h, g);

        g.gridy = 1;
        JLabel sub = new JLabel("Join StudySync today");
        sub.setFont(F_SUBTITLE);
        sub.setForeground(C_MUTED);
        card.add(sub, g);

        g.gridy = 2;
        g.insets = new Insets(14, 0, 3, 0);
        card.add(makeLabel("Username"), g);

        g.gridy = 3;
        g.insets = new Insets(0, 0, 5, 0);
        signupUser = styledField(20);
        card.add(signupUser, g);

        g.gridy = 4;
        g.insets = new Insets(5, 0, 3, 0);
        card.add(makeLabel("Password (min 8 chars)"), g);

        g.gridy = 5;
        g.insets = new Insets(0, 0, 5, 0);
        signupPass = styledPassField(20);
        card.add(signupPass, g);

        g.gridy = 6;
        g.insets = new Insets(5, 0, 3, 0);
        card.add(makeLabel("Confirm Password"), g);

        g.gridy = 7;
        g.insets = new Insets(0, 0, 5, 0);
        signupConfirm = styledPassField(20);
        card.add(signupConfirm, g);

        g.gridy = 8;
        signupError = new JLabel(" ");
        signupError.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        signupError.setForeground(C_ROSE);
        card.add(signupError, g);

        g.gridy = 9;
        g.insets = new Insets(2, 0, 8, 0);
        signupBtn = primaryButton("Create Account", C_EMERALD);
        signupBtn.addActionListener(e -> doSignup());
        card.add(signupBtn, g);
        signupConfirm.addActionListener(e -> doSignup());

        g.gridy = 10;
        g.insets = new Insets(0, 0, 0, 0);
        JPanel switchRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        switchRow.setBackground(C_BG);
        JLabel q = new JLabel("Already have an account?");
        q.setFont(F_BODY);
        q.setForeground(C_MUTED);
        JLabel link = linkLabel("Sign in");
        link.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                showCard("login");
            }
        });
        switchRow.add(q);
        switchRow.add(link);
        card.add(switchRow, g);

        return card;
    }

    private void doLogin() {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword());
        if (user.isEmpty() || pass.isEmpty()) {
            errorLabel.setText("Please fill in all fields.");
            return;
        }
        if (authService.login(user, pass)) {
            dispose();
            SwingUtilities.invokeLater(() -> new DashboardUI(user));
        } else {
            errorLabel.setText("Invalid username or password.");
            passwordField.setText("");
        }
    }

    private void doSignup() {
        String user = signupUser.getText().trim();
        String pass = new String(signupPass.getPassword());
        String conf = new String(signupConfirm.getPassword());

        if (user.isEmpty() || pass.isEmpty() || conf.isEmpty()) {
            signupError.setText("Please fill in all fields.");
            return;
        }
        if (!pass.equals(conf)) {
            signupError.setText("Passwords do not match.");
            return;
        }
        if (authService.signup(user, pass)) {
            signupError.setText(" ");
            signupUser.setText("");
            signupPass.setText("");
            signupConfirm.setText("");
            JOptionPane.showMessageDialog(this,
                    "Account created! You can now sign in.", "Success",
                    JOptionPane.INFORMATION_MESSAGE);
            showCard("login");
        } else {
            signupError.setText("Signup failed. Username rules and 8+ char password required.");
        }
    }

    private JLabel makeLabel(String text) {
        JLabel l = new JLabel(text);
        l.setFont(F_LABEL);
        l.setForeground(C_SLATE);
        return l;
    }

    private JTextField styledField(int cols) {
        JTextField f = new JTextField(cols);
        styleInput(f);
        return f;
    }

    private JPasswordField styledPassField(int cols) {
        JPasswordField f = new JPasswordField(cols);
        styleInput(f);
        return f;
    }

    private void styleInput(JTextField f) {
        f.setFont(F_BODY);
        f.setPreferredSize(new Dimension(0, 38));
        f.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(203, 213, 225), 1, true),
                new EmptyBorder(6, 10, 6, 10)));
        f.setBackground(C_WHITE);
        f.setForeground(C_SLATE);
    }

    private JButton primaryButton(String text, Color bg) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? bg.darker() : getModel().isRollover() ? bg.brighter() : bg);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 8, 8);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setForeground(C_WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setPreferredSize(new Dimension(0, 42));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JLabel linkLabel(String text) {
        JLabel l = new JLabel("<html><u>" + text + "</u></html>");
        l.setFont(F_BODY);
        l.setForeground(C_INDIGO);
        l.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return l;
    }
}
