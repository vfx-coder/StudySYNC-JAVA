package com.studysync.planner;

import java.util.*;
import com.studysync.model.Subject;
import com.studysync.core.PriorityEngine;

public final class StudyPlanner {

    public static final int PERCENT_PER_HOUR = 10;

    private StudyPlanner() { /* utility */ }

    public static Map<Integer, Integer> generatePlan(List<Subject> subjects, int studyHours) {
        Map<Integer, Integer> allocation = new HashMap<>();
        if (subjects == null || subjects.isEmpty() || studyHours <= 0) return allocation;

        List<SubjectPriority> active = new ArrayList<>();
        double totalPriority = 0.0;
        for (Subject s : subjects) {
            double p = PriorityEngine.calculatePriority(s);
            if (p == PriorityEngine.INACTIVE) continue;
            active.add(new SubjectPriority(s, p));
            totalPriority += p;
        }
        if (active.isEmpty()) return allocation;

        active.sort((a, b) -> Double.compare(b.priority, a.priority));

        int remaining = studyHours;
        for (SubjectPriority sp : active) {
            int needed = hoursNeededToFinish(sp.subject);
            if (needed <= 0) continue;

            double ratio = totalPriority > 0 ? sp.priority / totalPriority : 1.0 / active.size();
            int alloc = (int) Math.floor(ratio * studyHours);
            alloc = Math.min(alloc, needed);
            alloc = Math.min(alloc, remaining);
            if (alloc < 0) alloc = 0;
            allocation.put(sp.subject.getId(), alloc);
            remaining -= alloc;
        }

        boolean progressed = true;
        while (remaining > 0 && progressed) {
            progressed = false;
            for (SubjectPriority sp : active) {
                if (remaining <= 0) break;
                int cur    = allocation.getOrDefault(sp.subject.getId(), 0);
                int needed = hoursNeededToFinish(sp.subject);
                if (cur < needed) {
                    allocation.put(sp.subject.getId(), cur + 1);
                    remaining--;
                    progressed = true;
                }
            }
        }

        allocation.values().removeIf(h -> h <= 0);
        return allocation;
    }

    public static int hoursNeededToFinish(Subject s) {
        int remaining = 100 - s.getCompletion();
        if (remaining <= 0) return 0;
        return (int) Math.ceil(remaining / (double) PERCENT_PER_HOUR);
    }

    private static final class SubjectPriority {
        final Subject subject;
        final double  priority;
        SubjectPriority(Subject s, double p) { subject = s; priority = p; }
    }
}
