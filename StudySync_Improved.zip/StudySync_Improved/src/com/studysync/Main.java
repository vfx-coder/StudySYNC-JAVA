package com.studysync;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import com.studysync.ui.LoginUI;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                boolean nimbusSet = false;
                for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                    if ("Nimbus".equals(info.getName())) {
                        UIManager.setLookAndFeel(info.getClassName());
                        nimbusSet = true;
                        break;
                    }
                }
                if (!nimbusSet) {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
            } catch (Exception ignored) { /* fall back to default LAF */ }
            new LoginUI();
        });
    }
}
