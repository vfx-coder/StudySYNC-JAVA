package com.studysync.model;

import java.util.Objects;

public class Subject {

    public static final int MIN_DIFFICULTY = 1;
    public static final int MAX_DIFFICULTY = 5;

    private final int id;
    private String name;
    private int difficulty;
    private int completion;
    private int daysLeft;
    private String lastUpdated;

    public Subject(int id, String name, int difficulty, int completion,
            int daysLeft, String lastUpdated) {
        this.id = id;
        setName(name);
        setDifficulty(difficulty);
        setCompletion(completion);
        setDaysLeft(daysLeft);
        setLastUpdated(lastUpdated);
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public int getCompletion() {
        return completion;
    }

    public int getDaysLeft() {
        return daysLeft;
    }

    public String getLastUpdated() {
        return lastUpdated;
    }

    public void setName(String name) {
        this.name = (name == null) ? "" : name.trim();
    }

    public void setDifficulty(int difficulty) {
        this.difficulty = Math.max(MIN_DIFFICULTY, Math.min(MAX_DIFFICULTY, difficulty));
    }

    public void setCompletion(int completion) {
        this.completion = Math.max(0, Math.min(100, completion));
    }

    public void setDaysLeft(int daysLeft) {
        this.daysLeft = Math.max(0, daysLeft);
    }

    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = Objects.requireNonNullElse(lastUpdated, "");
    }

    @Override
    public String toString() {
        return "ID: " + id + " | " + name + " | Diff: " + difficulty
                + " | Completion: " + completion + "% | Days Left: " + daysLeft;
    }
}
