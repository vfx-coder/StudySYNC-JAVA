package com.studysync.core;

import com.studysync.model.Subject;

public final class PriorityEngine {

    public static final double INACTIVE = -1.0;

    public static final double HIGH_THRESHOLD   = 70.0;
    public static final double MEDIUM_THRESHOLD = 40.0;

    private PriorityEngine() { /* utility */ }

    public static double calculatePriority(Subject subject) {
        if (subject == null) return INACTIVE;
        int remaining = 100 - subject.getCompletion();
        int daysLeft  = subject.getDaysLeft();
        if (daysLeft <= 0 || remaining <= 0) return INACTIVE;

        int difficulty = Math.max(1, Math.min(5, subject.getDifficulty()));

        double priority = (difficulty * 15.0) + (remaining * 0.8);

        priority += (remaining / (double) daysLeft) * 10.0;

        // Deadline boosts
        if      (daysLeft <= 3) priority += 50;
        else if (daysLeft <= 7) priority += 25;

        return priority;
    }

    public static String label(double priority) {
        if (priority >= HIGH_THRESHOLD)   return "High";
        if (priority >= MEDIUM_THRESHOLD) return "Medium";
        if (priority > 0)                 return "Low";
        return "-";
    }
}
