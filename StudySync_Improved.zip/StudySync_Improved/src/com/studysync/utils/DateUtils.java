package com.studysync.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class DateUtils {

    public static String getCurrentDate() {
        return LocalDate.now().toString();
    }

    public static int daysBetween(String date1, String date2) {
        LocalDate d1 = LocalDate.parse(date1);
        LocalDate d2 = LocalDate.parse(date2);
        return (int) java.time.temporal.ChronoUnit.DAYS.between(d1, d2);
    }

    public static String formatDate(String dateStr) {
        if (dateStr == null || dateStr.isEmpty()) return "Never";
        try {
            LocalDate date = LocalDate.parse(dateStr);
            return date.format(DateTimeFormatter.ofPattern("EEEE, dd MMMM yyyy"));
        } catch (Exception e) {
            return dateStr;
        }
    }
}
