package com.studysync.utils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import com.studysync.model.Subject;

public final class FileUtils {

    private FileUtils() { /* utility */ }

    public static void saveSubjects(List<Subject> subjects, String filename) {
        File dest = new File(filename);
        if (dest.getParentFile() != null) dest.getParentFile().mkdirs();
        File tmp = new File(filename + ".tmp");

        try (PrintWriter w = new PrintWriter(new OutputStreamWriter(
                new FileOutputStream(tmp), StandardCharsets.UTF_8))) {
            for (Subject s : subjects) {
                w.println(toFileLine(s));
            }
        } catch (IOException e) {
            System.err.println("[FileUtils] Error saving: " + e.getMessage());
            return;
        }
        atomicMove(tmp, dest);
    }

    public static List<Subject> loadSubjects(String filename) {
        List<Subject> subjects = new ArrayList<>();
        File file = new File(filename);
        if (!file.exists()) return subjects;

        int id = 0;
        try (BufferedReader r = new BufferedReader(new InputStreamReader(
                new FileInputStream(file), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;
                Subject s = parseLine(line, id + 1);
                if (s != null) { subjects.add(s); id++; }
            }
        } catch (IOException e) {
            System.err.println("[FileUtils] Error loading: " + e.getMessage());
        }
        return subjects;
    }

    public static int peekNextId(List<Subject> existing) {
        int max = 0;
        for (Subject s : existing) max = Math.max(max, s.getId());
        return max + 1;
    }

    private static String toFileLine(Subject s) {
        return encode(s.getName()) + " " + s.getDifficulty() + " " + s.getDaysLeft()
                + " " + s.getCompletion() + " 0 0 " + s.getLastUpdated();
    }

    private static Subject parseLine(String line, int id) {
        String[] parts = line.split("\\s+");
        if (parts.length < 4) return null;
        try {
            String name       = decode(parts[0]);
            int    difficulty = Integer.parseInt(parts[1]);
            int    daysLeft   = Integer.parseInt(parts[2]);
            int    completion = Integer.parseInt(parts[3]);
            String lastUpdated = (parts.length > 6) ? parts[6] : DateUtils.getCurrentDate();
            return new Subject(id, name, difficulty, completion, daysLeft, lastUpdated);
        } catch (NumberFormatException e) {
            System.err.println("[FileUtils] Skipping malformed line: " + line);
            return null;
        }
    }

    private static void atomicMove(File tmp, File dest) {
        try {
            Files.move(tmp.toPath(), dest.toPath(),
                    StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ame) {
            try { Files.move(tmp.toPath(), dest.toPath(), StandardCopyOption.REPLACE_EXISTING); }
            catch (IOException e) { System.err.println("[FileUtils] move failed: " + e.getMessage()); }
        } catch (IOException e) {
            System.err.println("[FileUtils] move failed: " + e.getMessage());
        }
    }

    private static String encode(String s) {
        try {
            return java.net.URLEncoder.encode(s, StandardCharsets.UTF_8).replace("+", "%20");
        } catch (Exception e) {
            return s.replaceAll("\\s+", "_");
        }
    }

    private static String decode(String s) {
        try {
            return java.net.URLDecoder.decode(s, StandardCharsets.UTF_8);
        } catch (Exception e) {
            return s;
        }
    }
}
