#!/bin/bash
java -cp out com.studysync.Main
